# dashboard/urls.py
from django.urls import path
from .views import DashboardView

urlpatterns = [
    path('', DashboardView.as_view(), name='dashboard'),
    # path('', DashboardView.as_view(), name='mentor-dashboard'),
    # path('', DashboardView.as_view(), name='donor-dashboard'),
]

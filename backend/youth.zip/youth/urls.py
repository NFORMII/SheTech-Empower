# mentor/urls.py

from django.urls import path

urlpatterns = [
]

from django.contrib import admin
from .models import Mentor

admin.site.register(Mentor)